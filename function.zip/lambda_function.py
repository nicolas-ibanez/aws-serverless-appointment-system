import json
import boto3
from datetime import datetime

# Conectamos con DynamoDB
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('AnomalyDetectionTable')

def lambda_handler(event, context):
    # Generamos un timestamp (la hora actual)
    now = datetime.now().isoformat()
    
    # Preparamos el "Item" (el dato a guardar)
    item = {
        'DEVICE_ID': 'SENSOR_01',
        'TIMESTAMP': now,
        'Data': 'Normal Operation',
        'Status': 'PENDING_ANALYSIS'
    }
    
    # Guardamos en la tabla
    table.put_item(Item=item)
    
    return {
        'statusCode': 200,
        'body': json.dumps(f'Dato guardado con éxito a las {now}')
    }